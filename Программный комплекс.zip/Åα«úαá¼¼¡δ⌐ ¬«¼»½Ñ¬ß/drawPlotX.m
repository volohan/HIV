function drawPlotX(fig, x, t)
figure(fig);
hold on;
ylabels = ['S1', 'S2', 'I1', 'I2', 'V ', 'E '];
r = size(x,2);
for i = 1 : r
subplot(3,2,i),plot(t,x(:,i))
title(strcat(ylabels(2*i-1), ylabels(2*i)));
xlabel('t, ����');
hold on;
end
end
