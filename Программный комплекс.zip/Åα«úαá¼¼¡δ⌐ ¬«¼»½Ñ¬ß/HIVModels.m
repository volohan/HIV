function varargout = HIVModels(varargin)
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @HIVModels_OpeningFcn, ...
                   'gui_OutputFcn',  @HIVModels_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before HIVModels is made visible.
function HIVModels_OpeningFcn(hObject, eventdata, handles, varargin)
h = findobj('Tag','figMain');
set(handles.rbtnHIV4, 'Value', 0);
set(handles.rbtnHIV6, 'Value', 0);
set(handles.rbtnHIV7, 'Value', 0);
if(strcmp(getappdata(h, 'Model'), 'hiv4'))
    set(handles.rbtnHIV4, 'Value', 1);
elseif(strcmp(getappdata(h, 'Model'), 'hiv6'))
    set(handles.rbtnHIV6, 'Value', 1);
elseif(strcmp(getappdata(h, 'Model'), 'hiv7'))
    set(handles.rbtnHIV7, 'Value', 1);
end

% Choose default command line output for HIVModels
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);


% --- Outputs from this function are returned to the command line.
function varargout = HIVModels_OutputFcn(hObject, eventdata, handles) 
% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in btnModelOk.
function btnModelOk_Callback(hObject, eventdata, handles)
h = findobj('Tag','figMain');
if(get(handles.rbtnHIV4, 'Value') == 1)
    setappdata(h, 'Model', 'hiv4');
elseif(get(handles.rbtnHIV6, 'Value') == 1)
    setappdata(h, 'Model', 'hiv6'); 
elseif(get(handles.rbtnHIV7, 'Value') == 1)
    setappdata(h, 'Model', 'hiv7'); 
end
close HIVModels;
