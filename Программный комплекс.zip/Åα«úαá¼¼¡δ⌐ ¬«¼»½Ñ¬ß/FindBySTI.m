function varargout = FindBySTI(varargin)
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @FindBySTI_OpeningFcn, ...
                   'gui_OutputFcn',  @FindBySTI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before FindBySTI is made visible.
function FindBySTI_OpeningFcn(hObject, eventdata, handles, varargin)
h = findobj('Tag','figMain');
T_p = getappdata(h, 'T_p');
T_sp = getappdata(h, 'T_sp');
T_el = getappdata(h, 'T_el');
num_dist = getappdata(h, 'num_dist');
set(handles.editTp,'String', num2str(T_p));
set(handles.editTsp,'String', num2str(T_sp));
set(handles.editTel,'String', num2str(T_el));
set(handles.editNumDist,'String', num2str(num_dist));

% Choose default command line output for FindBySTI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% --- Outputs from this function are returned to the command line.
function varargout = FindBySTI_OutputFcn(hObject, eventdata, handles) 
% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in btnXf.
function btnXf_Callback(hObject, eventdata, handles)
h = findobj('Tag','figMain');
if(strcmp(getappdata(h, 'Model'), 'hiv4'))
    ChangeXfhiv4;
elseif(strcmp(getappdata(h, 'Model'), 'hiv6'))
    ChangeXfhiv6;
elseif(strcmp(getappdata(h, 'Model'), 'hiv7'))
    ChangeXfhiv7;
end


function editTp_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editTp_CreateFcn(hObject, eventdata, handles)
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editTsp_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editTsp_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editTel_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function editTel_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editNumDist_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editNumDist_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in checkDisturb.
function checkDisturb_Callback(hObject, eventdata, handles)
if(get(hObject,'Value') == 1)
    set(handles.editTel, 'Enable', 'on');
    set(handles.editNumDist, 'Enable', 'on');
else
    set(handles.editTel, 'Enable', 'off');
    set(handles.editNumDist, 'Enable', 'off');
end

% --- Executes on button press in btnStartSTI.
function btnStartSTI_Callback(hObject, eventdata, handles)
h = findobj('Tag','figMain');
%Current values of edit
T_p = str2double(get(handles.editTp,'String'));
T_sp = str2double(get(handles.editTsp,'String'));
T_el = str2double(get(handles.editTel,'String'));
num_dist = str2double(get(handles.editNumDist,'String'));

%Prepare for call function STI(D)
mfun = getappdata(h, 'Model');
if(strcmp(mfun, 'hiv4'))
    X0 = getappdata(h, 'X04');
    Xf = getappdata(h, 'Xf4');
elseif(strcmp(mfun, 'hiv6'))
    X0 = getappdata(h, 'X06');
    Xf = getappdata(h, 'Xf6');
elseif(strcmp(mfun, 'hiv7'))
    X0 = getappdata(h, 'X07');
    Xf = getappdata(h, 'Xf7');
end
U_min = getappdata(h, 'U_min');
U_max = getappdata(h, 'U_max');
t0 = getappdata(h, 't0');
tf = getappdata(h, 'tf');
setappdata(h, 'T_p', T_p);
setappdata(h, 'T_sp', T_sp);
setappdata(h, 'T_el', T_el);
setappdata(h, 'num_dist', num_dist);
if(get(handles.checkDisturb,'Value') == 1)
    [X,U,t,t_opt,J,J_arr] = STID(mfun, X0, Xf, U_min, U_max, t0, tf, T_p, T_sp, T_el, num_dist)
else
    [X,U,t,t_opt,J,J_arr] = STI(mfun, X0, Xf, U_min, U_max, t0, tf, T_p, T_sp)
end
setappdata(h, 'Xsti', X);
setappdata(h, 'Usti', U);
setappdata(h, 'tsti', t);
setappdata(h, 'toptsti', t_opt);
setappdata(h, 'Jsti', J);
setappdata(h, 'J_arrsti', J_arr);

fig = figure;
drawPlotX(fig,X, t);
setappdata(h, 'fig', fig);

close FindBySTI;
