function varargout = ConstParamQ20(varargin)
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ConstParamQ20_OpeningFcn, ...
                   'gui_OutputFcn',  @ConstParamQ20_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ConstParamQ20 is made visible.
function ConstParamQ20_OpeningFcn(hObject, eventdata, handles, varargin)

% Choose default command line output for ConstParamQ20
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% --- Outputs from this function are returned to the command line.
function varargout = ConstParamQ20_OutputFcn(hObject, eventdata, handles) 
% Get default command line output from handles structure
varargout{1} = handles.output;


function editmu1_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editmu1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editk1_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editk1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function editm1_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function editm1_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editc_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editc_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editmu_E_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editmu_E_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editK_b_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function editK_b_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function editf_u1_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editf_u1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editmu2_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editmu2_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editd2_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editd2_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editk2_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editk2_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editm2_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editm2_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editro2_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editro2_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editK_d_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editK_d_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editdelta_E_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editdelta_E_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function editd1_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function editd1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function editdelta_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function editdelta_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function editN_T_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function editN_T_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function editro1_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function editro1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function editb_E_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function editb_E_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function editd_E_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function editd_E_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btnConstParamQ20Ok.
function btnConstParamQ20Ok_Callback(hObject, eventdata, handles)
h = findobj('Tag','figMain');
%Operations for save value
close ConstParamQ20;
