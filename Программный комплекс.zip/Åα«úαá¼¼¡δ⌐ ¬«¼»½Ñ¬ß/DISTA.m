% Function 'DISTA' disturbs input control and computes phase vector X[t], 
% optimal value of functional cost J for controlability dynamic model with disturbed control.
% Parametres of function 'DISTA':
% mfun  - function of model's dynamic y = f(t,x,u) for Matlab ODE solver
% X_0   - initial point of phase vector;
% X_f   - final point of phase vector;
% U_min - left bound of control;
% U_max - right bound of control;
% t_0   - time samples;
% t_max - maximum finish time of models's integration;
% T_p   - time period of search optimal controls. 
% T_sp  - time subperiod of affecting constant controls (elementary site of control).
% T_el  - minimal time period of affecting constant controls.
% U     - etalon input (nondisturbed) control vector.
% ndist - number of disturbances.
function [X_dist_arr,J_dist_arr] = DISTA(mfun,X_0,X_f,U_min,U_max,t,T_p,T_sp,T_el,U,ndist)
% expand control vector
N_el = round( T_sp / T_el );
U_exp = U(:,1);
for i = 2:size(U,2)
    for j = 1:N_el
        U_exp = [U_exp, U(:,i)];
    end;
end;

X = SIM(mfun, X_0, U_exp, t(1), t(end), T_el);
J = Jcost(X, X_f, U_exp, t(1), t(end), T_el);

J_dist_arr = [];
X_dist_arr = [];

% Add noise to control vector (nonzero control to zero)
if ndist == 1
    J_dist_arr = zeros(1,size(U_exp,2));
    X_dist_arr = zeros(size(U_exp,2),size(X,2));
    parfor i = 1:size(U_exp,2)
        U_exp_dist = U_exp;
        J_dist = J;
        X_dist = X(end,:);
        % if control vector not equal zero,
        if( isequal( U_exp(:,i),U_min ) ) == false
            U_exp_dist(:,i) = U_min;
            X_dist = SIM(mfun, X(1,:), U_exp_dist, t(1), t(end), T_el);
            J_dist = Jcost(X_dist, X_f, U_exp_dist, t(1), t(end), T_el);
        end;
        X_dist_arr(i,:) = X_dist(end,:);
        J_dist_arr(1,i) = J_dist;
    end;
end