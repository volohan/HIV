%% Model of dynamic system HIV
%% dS1/dt = mu1 - d1*S1 - (1-u1)*k1*V*S1
%% dI1/dt = (1-u1)*k1*V*S1 - delta*I1 - m1*E*I1
%% dV/dt = (1-u2)N_T*delta*I1 - c*V - [(1-u1)*ro1*k1*S1]*V
%% dE/dt = mu_E + b_E*(I1)*E/(I1+K_b) - d_E*(I1)*E/(I1+K_d) - delta_E*E
%% M-Function for ODE Solver
function y = hiv4(t,x,u);
%% Model's Parametres
mu1 = 10000;
d1  = 0.01;
k1  =  8 * 1e-7;
delta = 0.7;
m1  = 1e-5;
N_T = 100;
c   = 13;
ro1 = 1;
mu_E= 1;
b_E = 0.3;
K_b = 100;
d_E = 0.25;
K_d = 500;
delta_E = 0.1;
%% Transition to new variables
S1 = x(1);
I1 = x(2);
V  = x(3);
E  = x(4);
%% System of HIV
y = zeros(4,1);
y(1,1) = mu1 - d1*S1 - (1 - u(1))*k1*V*S1;
y(2,1) = (1 - u(1))*k1*V*S1 - delta*I1 - m1*E*I1;
y(3,1) = (1 - u(2))*N_T*delta*(I1) - c*V -((1 - u(1))*ro1*k1*S1)*V;
y(4,1) = mu_E + b_E*(I1)*E/(I1 + K_b) - d_E*(I1)*E/(I1 + K_d) - delta_E * E;