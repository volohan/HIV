function [X,t] = SIM(mfun,X_0,U,t_0,t_max,dt)
fh = str2func(mfun);
t = t_0:dt:t_max;
X = X_0;
for i = 1:( size(t,2) - 1 )
    [buf_t, buf_x] = ode15s(fh, [t(i), t(i+1)], X(end, :), [t(i), t(i+1)], U(:,i));
    X = [X; buf_x(end, :) ];
end