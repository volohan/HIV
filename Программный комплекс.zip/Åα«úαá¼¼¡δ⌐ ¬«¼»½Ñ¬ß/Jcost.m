function J = Jcost(x, x_f, u, t_start, t_end, dt);
% calculate integral part of cost functional
R1 = 50000;
R2 = 50000;
u1=u(1,:);
u2=u(2,:);
Y = R1*(u1.^2) + R2*(u2.^2);
J_int = 0;
for i = 1 : length(Y)
    J_int = J_int + dt * Y(i);
end;
J_int = 0.5 * J_int;
% calculate terminal part of cost functional
Q = 0.0001;
S = 1;
P = 100000;
V_h = x_f(5);
E_h = x_f(6);
V = x(end,5);
E = x(end,6);
J_term = 0.5*(Q*((V-V_h)^2) + S*((E-E_h)^2) + P*(t_end^2));
% cost functional
J = J_term + J_int;
end