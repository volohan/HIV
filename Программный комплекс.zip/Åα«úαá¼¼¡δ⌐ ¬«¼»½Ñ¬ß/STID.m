% Function 'STI' computes phase vector X[t], controls U[t],
% optimal value of final time t_f and optimal value of functional cost J
% for controllability dynamic model.
% Parameters of function 'STI':
% mfun  - function of model's dynamic y = f(t,x,u) for Matlab ODE solver
% X_0   - initial point of phase vector;
% X_f   - final point of phase vector;
% U_min - left bound of control;
% U_max - right bound of control;
% t_0   - start time of models's integration;
% t_max - maximum finish time of models's integration;
% T_p   - time period of search optimal controls. 
% T_sp  - time subperiod of affecting constant controls (elementary site of control). 
% T_el  - minimal time period of affecting constant controls.
% ndist - number of disturbances.
function [X,U,t,t_f,J,J_arr] = STID(mfun,X_0,X_f,U_min,U_max,t_0,t_max,T_p,T_sp,T_el,num_dist)
%% Validation of input data
%if maximum value of time less than minimum value of time
if( t_max<t_0 )
    % exchange time's bounds values 
    [t_max, t_0] = deal(t_0, t_max);
end
% If the time period is not divisible
if( mod( t_max - t_0, T_sp ) ~= 0 )
    %then adjust the time
    t_max = t_max + ( T_sp - mod( t_max - t_0, T_sp ) )
end;
t = t_0:T_sp:t_max;
N    = round( t_max / T_sp ); 
N_p  = round( t_max / T_p  ); 
N_sp = round( T_p   / T_sp );
%% Initialization
% Dimension of state-vector
n = size(X_0,1);
X = [X_0'];

% Dimension of control vector
r = size(U_min,1);
U = [];
% Array of values of optimal cost on each combination of control vector on time period T_p
% [in all 2^(r*N_sp)=(2^N_sp)*(2^N_sp)*...*(2^N_sp) combinatios  control vector on time period T_p]
J_arr = zeros(2^(r*N_sp),1);


%% Main loop  
% For each local time period T_p
for k = 0:(N_p-1)
    k
    % we find one of combination of control vector that minimizes cost functional J on (local) time period T_p
    % (we can use parallel cycle 'parfor' because integration of the state-system on various combinations of control vector can be performed independently)
    parfor i = 1 : 2^(r*N_sp)
        U_p=zeros(r,N_sp);
        for u_idx = 1 : r
            U_p(u_idx,:) = U_max(u_idx) * binary2vector( bitand(bitshift((i-1),-(u_idx-1)*N_sp),(2^N_sp - 1)),N_sp );
            u = U_p(u_idx,:);
            u(u==0)=U_min(u_idx);
            U_p(u_idx,:)=u;
        end;    
        % Integrating the state-system on each subperiod T_sp of current period T_sp 
        % and save values of state-vector in the end of subperiods
        t_p_start = t( N_sp*k+1 );
        t_p_end   = t( N_sp*(k+1)+1 );
        x_i = SIM(mfun, X(end,:), U_p, t_p_start, t_p_end, T_sp);
        X_p = x_i;
        % calculate terminal part of cost functional
        J_arr(i,1) = Jcost(X_p, X_f, U_p, t_p_start, t_p_end, T_sp);
        % calculate J_max for disturbed control
        if(num_dist == 1 )
            t_p = k*T_p:T_sp:(k+1)*T_p;
            [X_dist_arr,J_dist_arr] = DISTA(mfun,X(end,:),X_f,U_min,U_max,t_p,T_p,T_sp,T_el,[U_p(:,1),U_p],num_dist);
            J_arr(i,1) = -min(-J_dist_arr);
        end;
    end
    % Find index of minimum value of cost functional
    [buf_J,i]=min(J_arr);
    % Build combination of the optimal vector
    u_opt = zeros(r,N_sp);
    for u_idx = 1 : r
        u_opt(u_idx,:) = U_max(u_idx) * binary2vector( bitand(bitshift((i-1),-(u_idx-1)*N_sp),(2^N_sp - 1)),N_sp );
    end;
    % Add optimal control (on current time period T_p) to the general control vector
    U = [U, u_opt];
    % Integrate state-system again (we don't save state-vector because it may require a strong memory consumption for large number of combinations)
    t_p_start = t( N_sp*k+1 );
    t_p_end   = t( N_sp*(k+1)+1 );
    x_i = SIM(mfun, X(end,:), u_opt, t_p_start, t_p_end, T_sp);
    X = [X; x_i(2:end, :)];
end

%% Postprocessing
% Calculate all values of functional cost
J_arr = zeros(1,size(t,2));
J_arr(1,1) = Jcost(X(1,:), X_f, zeros(r,1), t(1), t(1), T_sp);
for i=2:size(t,2)
    J_arr(1,i) = Jcost(X(1:i,:), X_f, U(:,1:(i-1)), t(1), t(i), T_sp);
end;
% Find minimum of functional cost
[J,i]=min(J_arr);
t_f = t(i);
% Insert in control vector first value (because control of model begins with t_0 )
U=[U(:,1),U];

