function f = optP(p, x_i, z_i, F)
sum_F = zeros(size(F,2), 1);
for i = 1:size(p,2)
    sum_F = sum_F + p(1,i) * F(i,:)' ;
end
f = dot( x_i - z_i, sum_F );