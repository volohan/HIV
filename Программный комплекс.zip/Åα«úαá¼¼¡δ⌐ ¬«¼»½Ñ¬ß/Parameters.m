function varargout = Parameters(varargin)
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Parameters_OpeningFcn, ...
                   'gui_OutputFcn',  @Parameters_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Parameters is made visible.
function Parameters_OpeningFcn(hObject, eventdata, handles, varargin)
% Choose default command line output for Parameters
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);


% --- Outputs from this function are returned to the command line.
function varargout = Parameters_OutputFcn(hObject, eventdata, handles) 
% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in btnParamQ.
function btnParamQ_Callback(hObject, eventdata, handles)
h = findobj('Tag','figMain');
if(strcmp(getappdata(h, 'Model'), 'hiv4'))
    ConstParamQ14;
elseif(strcmp(getappdata(h, 'Model'), 'hiv6') || strcmp(getappdata(h, 'Model'), 'hiv7'))
    ConstParamQ20;
end


% --- Executes on button press in btnX0.
function btnX0_Callback(hObject, eventdata, handles)
h = findobj('Tag','figMain');
if(strcmp(getappdata(h, 'Model'), 'hiv4'))
    ChangeX0hiv4;
elseif(strcmp(getappdata(h, 'Model'), 'hiv6'))
    ChangeX0hiv6;
elseif(strcmp(getappdata(h, 'Model'), 'hiv7'))
    ChangeX0hiv7;
end


% --- Executes on button press in btnControlBounds.
function btnControlBounds_Callback(hObject, eventdata, handles)
ControlBounds;


% --- Executes on button press in btnT.
function btnT_Callback(hObject, eventdata, handles)
TimeParameters;


% --- Executes on button press in btnParamOk.
function btnParamOk_Callback(hObject, eventdata, handles)
close Parameters;
