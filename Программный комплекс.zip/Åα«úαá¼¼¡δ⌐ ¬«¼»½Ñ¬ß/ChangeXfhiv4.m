function varargout = ChangeXfhiv4(varargin)
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ChangeXfhiv4_OpeningFcn, ...
                   'gui_OutputFcn',  @ChangeXfhiv4_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ChangeXfhiv4 is made visible.
function ChangeXfhiv4_OpeningFcn(hObject, eventdata, handles, varargin)
h = findobj('Tag','figMain');
Xf = getappdata(h, 'Xf4');
set(handles.editSfhiv4,'String', num2str(Xf(1)));
set(handles.editIfhiv4,'String', num2str(Xf(2)));
set(handles.editVfhiv4,'String', num2str(Xf(3)));
set(handles.editEfhiv4,'String', num2str(Xf(4)));


% Choose default command line output for ChangeXfhiv4
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);


% --- Outputs from this function are returned to the command line.
function varargout = ChangeXfhiv4_OutputFcn(hObject, eventdata, handles) 
% Get default command line output from handles structure
varargout{1} = handles.output;


function editSfhiv4_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editSfhiv4_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editIfhiv4_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editIfhiv4_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editVfhiv4_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editVfhiv4_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editEfhiv4_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editEfhiv4_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in btnXfhiv4Ok.
function btnXfhiv4Ok_Callback(hObject, eventdata, handles)
h = findobj('Tag','figMain');
Xf = zeros(4,1);
Xf(1) = str2double(get(handles.editSfhiv4,'String'));
Xf(2) = str2double(get(handles.editIfhiv4,'String'));
Xf(3) = str2double(get(handles.editVfhiv4,'String'));
Xf(4) = str2double(get(handles.editEfhiv4,'String'));
setappdata(h, 'Xf4', Xf);
close ChangeXfhiv4;