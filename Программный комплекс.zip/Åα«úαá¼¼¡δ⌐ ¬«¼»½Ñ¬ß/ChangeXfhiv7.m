function varargout = ChangeXfhiv7(varargin)
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ChangeXfhiv7_OpeningFcn, ...
                   'gui_OutputFcn',  @ChangeXfhiv7_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ChangeXfhiv7 is made visible.
function ChangeXfhiv7_OpeningFcn(hObject, eventdata, handles, varargin)
h = findobj('Tag','figMain');
Xf = getappdata(h, 'Xf7');
set(handles.editS1fhiv7,'String', num2str(Xf(1)));
set(handles.editS2fhiv7,'String', num2str(Xf(2)));
set(handles.editI1fhiv7,'String', num2str(Xf(3)));
set(handles.editI2fhiv7,'String', num2str(Xf(4)));
set(handles.editVifhiv7,'String', num2str(Xf(5)));
set(handles.editVnifhiv7,'String', num2str(Xf(6)));
set(handles.editEfhiv7,'String', num2str(Xf(7)));

% Choose default command line output for ChangeXfhiv7
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);


% --- Outputs from this function are returned to the command line.
function varargout = ChangeXfhiv7_OutputFcn(hObject, eventdata, handles) 
% Get default command line output from handles structure
varargout{1} = handles.output;


function editS1fhiv7_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editS1fhiv7_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editS2fhiv7_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editS2fhiv7_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editI1fhiv7_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editI1fhiv7_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editI2fhiv7_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editI2fhiv7_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editVifhiv7_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editVifhiv7_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editVnifhiv7_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editVnifhiv7_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function editEfhiv7_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editEfhiv7_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btnXfhiv7Ok.
function btnXfhiv7Ok_Callback(hObject, eventdata, handles)
h = findobj('Tag','figMain');
Xf = zeros(7,1);
Xf(1) = str2double(get(handles.editS1fhiv7,'String'));
Xf(2) = str2double(get(handles.editS2fhiv7,'String'));
Xf(3) = str2double(get(handles.editI1fhiv7,'String'));
Xf(4) = str2double(get(handles.editI2fhiv7,'String'));
Xf(5) = str2double(get(handles.editVifhiv7,'String'));
Xf(6) = str2double(get(handles.editVnifhiv7,'String'));
Xf(7) = str2double(get(handles.editEfhiv7,'String'));
setappdata(h, 'Xf7', Xf);
close ChangeXfhiv7;
