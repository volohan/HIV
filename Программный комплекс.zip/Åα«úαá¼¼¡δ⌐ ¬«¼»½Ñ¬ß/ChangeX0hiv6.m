function varargout = ChangeX0hiv6(varargin)
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ChangeX0hiv6_OpeningFcn, ...
                   'gui_OutputFcn',  @ChangeX0hiv6_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ChangeX0hiv6 is made visible.
function ChangeX0hiv6_OpeningFcn(hObject, eventdata, handles, varargin)
h = findobj('Tag','figMain');
X0 = getappdata(h, 'X06');
set(handles.editS10hiv6,'String', num2str(X0(1)));
set(handles.editS20hiv6,'String', num2str(X0(2)));
set(handles.editI10hiv6,'String', num2str(X0(3)));
set(handles.editI20hiv6,'String', num2str(X0(4)));
set(handles.editV0hiv6,'String', num2str(X0(5)));
set(handles.editE0hiv6,'String', num2str(X0(6)));

% Choose default command line output for ChangeX0hiv6
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);


% --- Outputs from this function are returned to the command line.
function varargout = ChangeX0hiv6_OutputFcn(hObject, eventdata, handles) 
% Get default command line output from handles structure
varargout{1} = handles.output;


function editS10hiv6_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editS10hiv6_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editS20hiv6_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editS20hiv6_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editI10hiv6_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editI10hiv6_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editI20hiv6_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editI20hiv6_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editV0hiv6_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editV0hiv6_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editE0hiv6_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editE0hiv6_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btnX0hiv6Ok.
function btnX0hiv6Ok_Callback(hObject, eventdata, handles)
h = findobj('Tag','figMain');
X0 = zeros(6,1);
X0(1) = str2double(get(handles.editS10hiv6,'String'));
X0(2) = str2double(get(handles.editS20hiv6,'String'));
X0(3) = str2double(get(handles.editI10hiv6,'String'));
X0(4) = str2double(get(handles.editI20hiv6,'String'));
X0(5) = str2double(get(handles.editV0hiv6,'String'));
X0(6) = str2double(get(handles.editE0hiv6,'String'));
setappdata(h, 'X06', X0);
close ChangeX0hiv6;
