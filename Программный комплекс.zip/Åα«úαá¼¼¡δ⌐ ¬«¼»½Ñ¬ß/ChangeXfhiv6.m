function varargout = ChangeXfhiv6(varargin)
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ChangeXfhiv6_OpeningFcn, ...
                   'gui_OutputFcn',  @ChangeXfhiv6_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ChangeXfhiv6 is made visible.
function ChangeXfhiv6_OpeningFcn(hObject, eventdata, handles, varargin)
h = findobj('Tag','figMain');
Xf = getappdata(h, 'Xf6');
set(handles.editS1fhiv6,'String', num2str(Xf(1)));
set(handles.editS2fhiv6,'String', num2str(Xf(2)));
set(handles.editI1fhiv6,'String', num2str(Xf(3)));
set(handles.editI2fhiv6,'String', num2str(Xf(4)));
set(handles.editVfhiv6,'String', num2str(Xf(5)));
set(handles.editEfhiv6,'String', num2str(Xf(6)));

% Choose default command line output for ChangeXfhiv6
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);


% --- Outputs from this function are returned to the command line.
function varargout = ChangeXfhiv6_OutputFcn(hObject, eventdata, handles) 
% Get default command line output from handles structure
varargout{1} = handles.output;


function editS1fhiv6_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editS1fhiv6_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editS2fhiv6_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editS2fhiv6_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editI1fhiv6_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function editI1fhiv6_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editI2fhiv6_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editI2fhiv6_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editVfhiv6_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editVfhiv6_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editEfhiv6_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editEfhiv6_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btnXfhiv6Ok.
function btnXfhiv6Ok_Callback(hObject, eventdata, handles)
h = findobj('Tag','figMain');
Xf = zeros(6,1);
Xf(1) = str2double(get(handles.editS1fhiv6,'String'));
Xf(2) = str2double(get(handles.editS2fhiv6,'String'));
Xf(3) = str2double(get(handles.editI1fhiv6,'String'));
Xf(4) = str2double(get(handles.editI2fhiv6,'String'));
Xf(5) = str2double(get(handles.editVfhiv6,'String'));
Xf(6) = str2double(get(handles.editEfhiv6,'String'));
setappdata(h, 'Xf6', Xf);
close ChangeXfhiv6;
