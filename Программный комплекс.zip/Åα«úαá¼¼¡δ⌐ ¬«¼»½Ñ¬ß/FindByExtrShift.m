function varargout = FindByExtrShift(varargin)
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @FindByExtrShift_OpeningFcn, ...
                   'gui_OutputFcn',  @FindByExtrShift_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before FindByExtrShift is made visible.
function FindByExtrShift_OpeningFcn(hObject, eventdata, handles, varargin)
h = findobj('Tag','figMain');
tz0 = getappdata(h, 'tz0');
tzf = getappdata(h, 'tzf');
dtz = getappdata(h, 'dtz');
PathToTz = getappdata(h, 'PathToTz');
PathToZ = getappdata(h, 'PathToZ');
set(handles.editTz0,'String', num2str(tz0));
set(handles.editTzf,'String', num2str(tzf));
set(handles.editDtz,'String', num2str(dtz));
set(handles.editPathToTz,'String', PathToTz);
set(handles.editPathToZ,'String', PathToZ);

% Choose default command line output for FindByExtrShift
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% --- Outputs from this function are returned to the command line.
function varargout = FindByExtrShift_OutputFcn(hObject, eventdata, handles) 
% Get default command line output from handles structure
varargout{1} = handles.output;


function editPathToZ_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function editPathToZ_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function editPathToTz_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editPathToTz_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editTz0_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function editTz0_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editDtz_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function editDtz_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editTzf_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editTzf_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btnStartFindByExtr.
function btnStartFindByExtr_Callback(hObject, eventdata, handles)
h = findobj('Tag','figMain');
%Current values of edit
PathToTz = get(handles.editPathToTz,'String');
PathToZ = get(handles.editPathToZ,'String');
tz0 = str2double(get(handles.editTz0,'String'));
tzf = str2double(get(handles.editTzf,'String'));
dtz = str2double(get(handles.editDtz,'String'));
setappdata(h, 'tz0', tz0);
setappdata(h, 'tzf', tzf);
setappdata(h, 'dtz', dtz);
setappdata(h, 'PathToTz', PathToTz);
setappdata(h, 'PathToZ', PathToZ);
%Radiobuttons for tz
tz = [];
if(get(handles.rbtnTzfile, 'Value') == 1)
    %tz from PathToTz
elseif(get(handles.rbtnTzmemory, 'Value') == 1)
    %t from STI
    tz = getappdata(h, 'tsti');
elseif(get(handles.rbtnTzrange, 'Value') == 1)
    tz = tz0 : dtz : tzf;
end
%transpose tz
tz = tz';

%Radiobuttons for z-leader
if(get(handles.rbtnZfile, 'Value') == 1)
    %z from PathToZ
elseif(get(handles.rbtnZmemory, 'Value') == 1)
    %X from STI
    z = getappdata(h, 'Xsti');
end

%Prepare for call function ExtrShift
mfun = getappdata(h, 'Model');
if(strcmp(mfun, 'hiv4'))
    X0 = getappdata(h, 'X04');
elseif(strcmp(mfun, 'hiv6'))
    X0 = getappdata(h, 'X06');
elseif(strcmp(mfun, 'hiv7'))
    X0 = getappdata(h, 'X07');
end
U_min = getappdata(h, 'U_min');
U_max = getappdata(h, 'U_max');

%for graphic
setappdata(h, 'tz', tz);
setappdata(h, 'z', z);

[X, U, t] = ExtrShift(mfun, X0, tz, z, U_min, U_max);

%Output data
setappdata(h, 'Xextr', X);
setappdata(h, 'Uextr', U);
setappdata(h, 'textr', t);

fig = getappdata(h, 'fig');
drawPlotX(fig,X,t);
setappdata(h, 'fig', fig);

close FindByExtrShift;
