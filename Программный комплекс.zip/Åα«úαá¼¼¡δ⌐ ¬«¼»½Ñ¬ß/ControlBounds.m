function varargout = ControlBounds(varargin)
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ControlBounds_OpeningFcn, ...
                   'gui_OutputFcn',  @ControlBounds_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ControlBounds is made visible.
function ControlBounds_OpeningFcn(hObject, eventdata, handles, varargin)
h = findobj('Tag','figMain');
U_min = getappdata(h, 'U_min');
U_max = getappdata(h, 'U_max');
set(handles.editU1_min,'String', num2str(U_min(1)));
set(handles.editU2_min,'String', num2str(U_min(2)));
set(handles.editU1_max,'String', num2str(U_max(1)));
set(handles.editU2_max,'String', num2str(U_max(2)));

% Choose default command line output for ControlBounds
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% --- Outputs from this function are returned to the command line.
function varargout = ControlBounds_OutputFcn(hObject, eventdata, handles) 
% Get default command line output from handles structure
varargout{1} = handles.output;



function editU1_min_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function editU1_min_CreateFcn(hObject, eventdata, handles)
% Hint: edit controls usually have a white background on Windows.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function editU1_max_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editU1_max_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editU2_min_Callback(hObject, eventdata, handles)



% --- Executes during object creation, after setting all properties.
function editU2_min_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editU2_max_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editU2_max_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in btnControlBoundsOk.
function btnControlBoundsOk_Callback(hObject, eventdata, handles)
h = findobj('Tag','figMain');
U_min = zeros(2,1);
U_max = zeros(2,1);
U_min(1) = str2double(get(handles.editU1_min,'String'));
U_min(2) = str2double(get(handles.editU2_min,'String'));
U_max(1) = str2double(get(handles.editU1_max,'String'));
U_max(2) = str2double(get(handles.editU2_max,'String'));
setappdata(h, 'U_min', U_min);
setappdata(h, 'U_max', U_max);
close ControlBounds;