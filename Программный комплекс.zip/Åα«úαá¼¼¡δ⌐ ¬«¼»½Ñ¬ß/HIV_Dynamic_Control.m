function varargout = HIV_Dynamic_Control(varargin)
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @HIV_Dynamic_Control_OpeningFcn, ...
                   'gui_OutputFcn',  @HIV_Dynamic_Control_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before HIV_Dynamic_Control is made visible.
function HIV_Dynamic_Control_OpeningFcn(hObject, eventdata, handles, varargin)
setappdata(handles.figMain, 'Model', 'hiv6');
setappdata(handles.figMain, 'PathToU', '');
setappdata(handles.figMain, 'PathToTz', '');
setappdata(handles.figMain, 'PathToZ', '');
setappdata(handles.figMain, 'X04', [1e6; 0.0001; 1; 10]);
setappdata(handles.figMain, 'X06', [1e6; 3198; 0.0001; 0.0001; 1; 10]);
setappdata(handles.figMain, 'X07', [1e6; 3198; 0.0001; 0.0001; 1; 0; 10]);
setappdata(handles.figMain, 'U_min', [0; 0]);
setappdata(handles.figMain, 'U_max', [0.7; 0.3]);
setappdata(handles.figMain, 't0', 0);
setappdata(handles.figMain, 'tf', 450);
setappdata(handles.figMain, 'dt', 1);
setappdata(handles.figMain, 'q14', [10000; 0.01; 8*1e-7; 0.7; 1e-5; 1e-5; 100; 13; 1; 1; 0.3; 100; 0.25; 500; 0.1]);
setappdata(handles.figMain, 'q20', [10000; 31.98; 0.01; 0.01; 8*1e-7; 1e-4; 0.7; 1e-5; 1e-5; 100; 13; 1; 1; 1; 0.3; 100; 0.25; 500; 0.1; 0.34]);
%Parameters of STI
setappdata(handles.figMain, 'T_p', 30);
setappdata(handles.figMain, 'T_sp', 5);
setappdata(handles.figMain, 'T_el', 1);
setappdata(handles.figMain, 'num_dist', 0);
setappdata(handles.figMain, 'Xf4', [967839; 76; 415; 353108]);
setappdata(handles.figMain, 'Xf6', [967839; 621; 76; 6; 415; 353108]);
setappdata(handles.figMain, 'Xf7', [967839; 621; 76; 6; 415; 0; 353108]);
%Output arguments [X,U,t,t_f,J,J_arr]
setappdata(handles.figMain, 'Xsti', []);
setappdata(handles.figMain, 'Usti', []);
setappdata(handles.figMain, 'tsti', []);
setappdata(handles.figMain, 'toptsti', []);
setappdata(handles.figMain, 'Jsti', []);
setappdata(handles.figMain, 'J_arrsti', []);
%Parameters of ExtrShift
setappdata(handles.figMain, 'tz', []);
setappdata(handles.figMain, 'z', []);
setappdata(handles.figMain, 'tz0', 0);
setappdata(handles.figMain, 'tzf', 450);
setappdata(handles.figMain, 'dtz', 1);
%Output arguments [X,U,t]
setappdata(handles.figMain, 'Xextr', []);
setappdata(handles.figMain, 'Uextr', []);
setappdata(handles.figMain, 'textr', []);
%Figure for graphics
setappdata(handles.figMain, 'fig', 0);
% Choose default command line output for HIV_Dynamic_Control
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% --- Outputs from this function are returned to the command line.
function varargout = HIV_Dynamic_Control_OutputFcn(hObject, eventdata, handles)
% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in btnPickModel.
function btnPickModel_Callback(hObject, eventdata, handles)
HIVModels;


% --- Executes on button press in btnModelling.
function btnModelling_Callback(hObject, eventdata, handles)
Modelling;


% --- Executes on button press in btnParameters.
function btnParameters_Callback(hObject, eventdata, handles)
Parameters;


% --- Executes on button press in btnFindControl.
function btnFindControl_Callback(hObject, eventdata, handles)
FindControl;


% --- Executes on button press in btnExit.
function btnExit_Callback(hObject, eventdata, handles)
close all;


% --------------------------------------------------------------------
function menuMain_Callback(hObject, eventdata, handles)
