%% Model of dynamic system HIV
%% dS1/dt = mu1 - d1*S1 - (1-u1)*k1*V*S1
%% dS2/dt = mu2 - d2*S2 - (1-f*u1)*k2*V*S2
%% dI1/dt = (1-u1)*k1*V*S1 - delta*I1 - m1*E*I1
%% dI2/dt = (1-f*u1)*k2*V*S2 - delta*I2 - m2*E*I2
%% dV/dt = (1-u2)N_T*delta*(I1 + I2) - c*V - [(1-u1)*ro1*k1*S1 + (1-f*u1)*ro2*k2*S2]*V
%% dE/dt = mu_E + b_E*(I1+I2)*E/(I1+I2+K_b) - d_E*(I1+I2)*E/(I1+I2+K_d) - delta_E*E
%% M-Function for ODE Solver
function y = hiv6(t,x,u);
%% Model's Parametres
mu1 = 10000;
mu2 = 31.98;
d1  = 0.01;
d2  = 0.01;
k1  =  8 * 1e-7;
k2  =  1e-4;
delta = 0.7;
m1  = 1e-5;
m2  = 1e-5;
N_T = 100;
c   = 13;
ro1 = 1;
ro2 = 1;
mu_E= 1;
b_E = 0.3;
K_b = 100;
d_E = 0.25;
K_d = 500;
delta_E = 0.1;
f_u1 = 0.34;
%% Transition to new variables
S1 = x(1);
S2 = x(2);
I1 = x(3);
I2 = x(4);
V  = x(5);
E  = x(6);
%% System of HIV
y = zeros(6,1);
y(1,1) = mu1 - d1*S1 - (1 - u(1))*k1*V*S1;
y(2,1) = mu2 - d2*S2 - (1 - f_u1*u(1))*k2*V*S2;
y(3,1) = (1 - u(1))*k1*V*S1 - delta*I1 - m1*E*I1;
y(4,1) = (1 - f_u1*u(1))*k2*V*S2 - delta*I2 - m2*E*I2;
y(5,1) = (1 - u(2))*N_T*delta*(I1+I2) - c*V -((1 - u(1))*ro1*k1*S1 + (1 - f_u1*u(1))*ro2*k2*S2)*V;
y(6,1) = mu_E + b_E*(I1 + I2)*E/(I1 + I2 + K_b) - d_E*(I1 + I2)*E/(I1 + I2 + K_d) - delta_E * E;