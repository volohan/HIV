function varargout = ChangeX0hiv4(varargin)
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ChangeX0hiv4_OpeningFcn, ...
                   'gui_OutputFcn',  @ChangeX0hiv4_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ChangeX0hiv4 is made visible.
function ChangeX0hiv4_OpeningFcn(hObject, eventdata, handles, varargin)
h = findobj('Tag','figMain');
X0 = getappdata(h, 'X04');
set(handles.editS0hiv4,'String', num2str(X0(1)));
set(handles.editI0hiv4,'String', num2str(X0(2)));
set(handles.editV0hiv4,'String', num2str(X0(3)));
set(handles.editE0hiv4,'String', num2str(X0(4)));

% Choose default command line output for ChangeX0hiv4
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);


% --- Outputs from this function are returned to the command line.
function varargout = ChangeX0hiv4_OutputFcn(hObject, eventdata, handles) 
% Get default command line output from handles structure
varargout{1} = handles.output;


function editS0hiv4_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editS0hiv4_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editI0hiv4_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editI0hiv4_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editV0hiv4_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editV0hiv4_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editE0hiv4_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editE0hiv4_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in btnX0hiv4Ok.
function btnX0hiv4Ok_Callback(hObject, eventdata, handles)
h = findobj('Tag','figMain');
X0 = zeros(4,1);
X0(1) = str2double(get(handles.editS0hiv4,'String'));
X0(2) = str2double(get(handles.editI0hiv4,'String'));
X0(3) = str2double(get(handles.editV0hiv4,'String'));
X0(4) = str2double(get(handles.editE0hiv4,'String'));
setappdata(h, 'X04', X0);
close ChangeX0hiv4;