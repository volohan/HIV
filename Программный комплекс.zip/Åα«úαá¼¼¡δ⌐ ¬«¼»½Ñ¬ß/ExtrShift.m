%% Parameters of function 'ExtrShift':
% mfun  - function of model's dynamic y = f(t,x,u) for Matlab ODE solver
% X_0   - initial point of phase vector;
% X - phase vector;
% U_min - left bound of control;
% U_max - right bound of control;
% t - time of models's integration (row-vector);
% leader - phase vector of Z-leader (matrix(dim(t)*dim(X))). 
% type_interp - type of interpolate;
function [X, U, t] = ExtrShift(mfun, X_0, t_lead, leader, U_min, U_max)
fh = str2func(mfun);
%% Controls
% Dimension of control vector
r = size(U_min,1);
U = []; 
U_space=zeros(2^r,r);
for i = 1 : 2^r
        U_buf=zeros(r,1);
        for u_idx = 1 : r
            U_buf(u_idx,:) = U_max(u_idx) * binary2vector( bitand(bitshift( (i-1), -(u_idx-1)), (2 - 1)), 1 );
            u = U_buf(u_idx,:);
            u(u==0)=U_min(u_idx);
            U_buf(u_idx,:)=u;
        end;  
        %Transpose and save variable U
        U_space(i,:) = U_buf';     
end
%% Z-model
%size of phase vector
N = size(X_0, 1);
X = [];
t = [];
% Interpolate Z-model
% for i = i : size(leader, 2)
%     leader(:, i) = interp1(t_lead, leader(:, i), t_lead, type_interp);
% end
%% Parametres for solve Optimization Task of Extreme Shift Algorithm 
% Sum(p_i) = 1
Aeq = ones(1, 2^r);
beq = 1;
% Bounds of probabilities
lb = zeros(1, 2^r);
ub = ones(1, 2^r);
% Initial point for starting optimization procedure
p0 = ones(1, 2^r)./(2^r);
options = optimset('Display','off','Diagnostics','off');
%% Extreme Shift Algorithm
for i = 1:(size(t_lead,1)-1)
    % Get value of X-Model phase vector at current time
    x_i = X_0;
    % Get value of Z-Model phase vector at current time
    z_i = leader(i,:)';
    
    % Vector of Values of right sides of system of ODE
    F = zeros(2^r, N);
    for j = 1 : 2^r
        F(j,:) = fh(t_lead(i), x_i, U_space(j,:))';
    end
    % Optimization Task of Extreme Shift Algorithm 
    f = @(p)optP(p, x_i, z_i, F);
    p = fmincon(f,p0,[],[],Aeq,beq,lb,ub,[],options);
    
    % Procedure of Selection of Control
    rand_p = rand(1,1);
    sum_p = 0;
    u_e = [];
    for j = 1 : size(p, 2)
        if( rand_p >= sum_p && rand_p < (sum_p + p(j) ) ) 
            u_e = U_space(j,:);
            break;
        end
        sum_p = sum_p + p(j);
    end
    
    [tval,X_0] = ode15s(fh,[t_lead(i) t_lead(i+1)],X_0, [t_lead(i) t_lead(i+1)], u_e );
    X = [X; X_0];
    % Update initial position
    X_0 = X_0(end,:)';
    % Save time
    t = [t; tval];
    % Save Control
    U = [U; u_e];
end;
%% Delete Distinct time
for ind=2:size(t, 1)
   if( abs( t( ind - 1 ) - t( ind ) )<1e-9)
       t(ind)= t(ind)+1e-9;
   end
end
X
U
t
end