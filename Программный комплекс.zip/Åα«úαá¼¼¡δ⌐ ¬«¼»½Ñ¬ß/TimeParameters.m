function varargout = TimeParameters(varargin)
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @TimeParameters_OpeningFcn, ...
                   'gui_OutputFcn',  @TimeParameters_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before TimeParameters is made visible.
function TimeParameters_OpeningFcn(hObject, eventdata, handles, varargin)
h = findobj('Tag','figMain');
t0 = getappdata(h, 't0');
tf = getappdata(h, 'tf');
dt = getappdata(h, 'dt');
set(handles.editT0,'String', num2str(t0));
set(handles.editTf,'String', num2str(tf));
set(handles.editDt,'String', num2str(dt));

% Choose default command line output for TimeParameters
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% --- Outputs from this function are returned to the command line.
function varargout = TimeParameters_OutputFcn(hObject, eventdata, handles) 
% Get default command line output from handles structure
varargout{1} = handles.output;



function editT0_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function editT0_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function editTf_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function editTf_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editDt_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function editDt_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btnTimeParametersOk.
function btnTimeParametersOk_Callback(hObject, eventdata, handles)
h = findobj('Tag','figMain');
t0 = str2double(get(handles.editT0,'String'));
tf = str2double(get(handles.editTf,'String'));
dt = str2double(get(handles.editDt,'String'));
setappdata(h, 't0', t0);
setappdata(h, 'tf', tf);
setappdata(h, 'dt', dt);
close TimeParameters;

