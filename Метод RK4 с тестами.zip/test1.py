from main import *
import matplotlib.pyplot as plt
import math

y0 = [math.e ** (1/2), math.e ** (-1/2)]  # начальное условие (значение y(x0))
x0 = 1  # начальное значение
xn = 10  # конечное значение
h = 1  # шаг


# функция правой части дифференциального уравнения (y' = f(x, y))
def f1(x, y1, y2):
    return x/y2


def f2(x, y1, y2):
    return -x/y1


# точное решение нашего примера
def exact_solution_1(x):
    return math.e ** (x*x/2)


def exact_solution_2(x):
    return math.e ** (-x*x/2)


# вызов метода Рунге-Кутта 4-го порядка
x, y = RK4([f1, f2], y0, x0, xn, h)
solution_x = np.arange(x0, xn + 0.01, 0.01)
exact_solutions = [exact_solution_1, exact_solution_2]
solution_y = [[exact_solution(xi) for exact_solution in exact_solutions] for xi
              in solution_x]

plt.subplot(211)
plt.plot(x, [yi[0] for yi in y], 'b--', label='Solution')
plt.plot(solution_x, [yi[0] for yi in solution_y], 'r-.', label='Exact')
plt.legend()
plt.ylabel('y(x)')
plt.subplot(212)
plt.plot(x, [yi[1] for yi in y], 'b--', label='Solution')
plt.plot(solution_x, [yi[1] for yi in solution_y], 'r-.', label='Exact')
plt.legend()
plt.xlabel('x')
plt.ylabel('y(x)')
plt.show()
