import math
from main import RK4
import numpy as np
import matplotlib.pyplot as plt

x0 = 3
y0 = 4
z0 = -4
(t0, tn, h) = (0, 1, 0.1)




def f1(t, x, y, z):
    return -x + y + z


def f2(t, x, y, z):
    return x - y + z

def f3(t, x, y, z):
    return x+ y - z


def g1(t):
    return 1 * math.e **t +2 * math.e ** (-2 * t)
def g2(t):
    return 1 * math.e **t + 3 * math.e ** (-2* t)
def g3(t):
    return 1 * math.e ** t - (2 + 3) * math.e**(-2 * t)




x, y = RK4([f1, f2, f3], [x0, y0, z0], t0, tn, h)
solution_x = np.arange(t0, tn + 0.01, 0.01)
exact_solutions = [g1, g2, g3]
solution_y = [[exact_solution(xi) for exact_solution in exact_solutions] for xi
              in solution_x]

plt.subplot(211)
plt.plot(x, [yi[0] for yi in y], 'b--', label='Solution')
plt.plot(solution_x, [yi[0] for yi in solution_y], 'r-.', label='Exact')
plt.legend()
plt.ylabel('y(x)')
plt.subplot(212)
plt.plot(x, [yi[1] for yi in y], 'b--', label='Solution')
plt.plot(solution_x, [yi[1] for yi in solution_y], 'r-.', label='Exact')
plt.legend()
plt.xlabel('x')
plt.ylabel('y(x)')
plt.show()
