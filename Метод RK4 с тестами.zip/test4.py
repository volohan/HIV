from main import *
import matplotlib.pyplot as plt
import math




# функция правой части дифференциального уравнения (y' = f(x, y))
def f1(t, x, y):
    return 2 * x + 4 * y + math.cos(t)


def f2(t, x, y):
    return -x - 2 * y + math.sin(t)


# точное решение нашего примера
def exact_solution_1(t):
    return -3 * math.sin(t) - 2 * math.cos(t) - 2 * t - 1 - 4


def exact_solution_2(t):
    return 2 * math.sin(t) + t + 2

x0 = 0  # начальное значение
y0 = [exact_solution_1(x0), exact_solution_2(x0)]  # начальное условие (значение y(x0))
xn = 10  # конечное значение
h = 2  # шаг


# вызов метода Рунге-Кутта 4-го порядка
x, y = RK4([f1, f2], y0, x0, xn, h)
solution_x = np.arange(x0, xn + 0.01, 0.01)
exact_solutions = [exact_solution_1, exact_solution_2]
solution_y = [[exact_solution(xi) for exact_solution in exact_solutions] for xi
              in solution_x]

plt.subplot(211)
plt.plot(x, [yi[0] for yi in y], 'b--', label='Solution')
plt.plot(solution_x, [yi[0] for yi in solution_y], 'r-.', label='Exact')
plt.legend()
plt.ylabel('y(x)')
plt.subplot(212)
plt.plot(x, [yi[1] for yi in y], 'b--', label='Solution')
plt.plot(solution_x, [yi[1] for yi in solution_y], 'r-.', label='Exact')
plt.legend()
plt.xlabel('x')
plt.ylabel('y(x)')
plt.show()
